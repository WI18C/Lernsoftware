﻿using System.Collections.Generic;

namespace Lernsoftware.Logic.CardboxAg
{
    public interface ICardBoxManager
    {
        List<CardBox> GetCardBoxes(int userID);

        void SaveCardBox(CardBox cardBox, int userID);
        void UpdateCardBox(CardBox originalCardBox, string cardBoxName);
        void DeleteCardBox();
    }
}

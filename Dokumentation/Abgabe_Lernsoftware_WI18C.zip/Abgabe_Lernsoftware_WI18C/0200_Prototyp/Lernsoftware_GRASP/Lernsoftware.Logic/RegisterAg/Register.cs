using System.Collections.Generic;

using Lernsoftware.Logic.FileCardAg;


namespace Lernsoftware.Logic.RegisterAg
{
    public class Register
    {
        #region parameters
        public int containingFileCards;
        public int counter;
        public int counterSuccess;
        public int RegisterId;
        public static int rIdCounter = 0;
        public List<FileCard> fileCards = new List<FileCard>();
        public int registerTryCounter;
        public int registerRightCounter;
        #endregion

        public Register()
        {
            RegisterId = rIdCounter;
            rIdCounter++;
        }
    }
}








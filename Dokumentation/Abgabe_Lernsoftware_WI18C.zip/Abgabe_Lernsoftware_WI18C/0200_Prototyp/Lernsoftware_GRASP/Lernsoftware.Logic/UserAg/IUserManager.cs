﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lernsoftware.Logic.UserAg
{
    public interface IUserManager
    {
        void ChangePassword(User user, string neu);
        void ChangeUsername(User user, string neu);
        Boolean DeleteUser(string name);
        User NewUser(string name, string pwd);
        User LoginUser(string name, string pwd);
        int GetUserId(string name);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Windows;
using static Lernsoftware.ucTopBar;
using static Lernsoftware.ucSettingsSideBar;
using static Lernsoftware.ucFileCardQuestion;
using static Lernsoftware.ucSettingsNewFileCard;
using static Lernsoftware.ucFileCardAnswer;
using Lernsoftware.Logic.UserAg;
using Lernsoftware.Logic.CardboxAg;

namespace Lernsoftware
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class SignIn : Window
    {
        public static bool UserIsLoggedIn = false;
        // Manager
        private IUserManager userManager = new UserManager();
        private ICardBoxManager cardBoxManager = new CardboxManager();
        // Persistent Data
        private User currentUser = null;
        private CardBox currentCardBox = null;
        private List<CardBox> cardBoxes;
        ucTopBar topBarComponent;
        // private Button targetButton = null;

        public SignIn()
        {
            InitializeComponent();
        }

        private void BtnSignIn_Click(object sender, RoutedEventArgs e)
        {
            currentUser = userManager.LoginUser(txtUserName.Text, txtPassword.Password);
            if (currentUser != null)
            {
                cardBoxes = cardBoxManager.GetCardBoxes(currentUser.UserId);
                ActivateSignedInMode();
            }
            else
            {
                MessageBox.Show("User Name or Password incorrect. Please try again.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                SignIn signIn = new SignIn();
                signIn.Show();
                this.Close();
            }
        }

        private void BtnRegister_Click(object sender, RoutedEventArgs e)
            {
                var pwd = txtRegisterPassword.Password;
                if (pwd == txtRegisterRepeat.Password)
                {
                    User user = userManager.NewUser(txtRegisterUserName.Text, txtRegisterPassword.Password);
                    if (user != null)
                    {
                        currentUser = user;
                        ActivateSignedInMode();
                    }
                    else
                        MessageBox.Show("User Name or Password incorrect. Please try again.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    MessageBox.Show("Password repetition incorrect. Please try again.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }

            public void ActivateSignedInMode()
            {
                UserIsLoggedIn = true;

                // adds navigation into Topbar
                topBarComponent = new ucTopBar(currentCardBox);
                topBarComponent.ChangePageEvent += TopBarComponent_ChangePage;
                topBarComponent.SignOut += Topbar_SignOut;
                topBar.Children.Add(topBarComponent);

                // adds side navigation
                ucSettingsSideBar sideBarComponent = new ucSettingsSideBar();
                sideBarComponent.ChangePageForEditingEvent += SideBarComponent_ChangePageForEditing;
                sideBarGrid.Children.Add(sideBarComponent);

                // sideBarComponentRegisters
                ucSideBar sideBarComponentRegisters = new ucSideBar();

                // switches FileCards from Question to Answer
                if (cardBoxes != null)
                {
                    ucFileCardQuestion fileCardQuestionComponent = new ucFileCardQuestion(cardBoxes[0]);
                    fileCardQuestionComponent.ChangeQuestionToAnswerEvent += BtnAnswer_PageChanged;
                    content.Children.Add(fileCardQuestionComponent);

                    // switches FileCards from Answer to Question
                    ucFileCardAnswer fileCardAnswerComponent = new ucFileCardAnswer(cardBoxes[0]);
                    fileCardAnswerComponent.ChangeAnswerToQuestionEvent += BtnQuestion_PageChanged;
                    content.Children.Add(fileCardAnswerComponent);
                }

                // createNewFileCard by using either Next-or Finished - Button
                // ChooseButton(targetButton);

                ucSettingsNewFileCard settingsNewFileCardComponent = new ucSettingsNewFileCard(currentCardBox);
                settingsNewFileCardComponent.SettingsNextFileCardEvent += BtnSettingsNext_PageChanged;
                content.Children.Add(settingsNewFileCardComponent);

                //ucSettingsNewFileCard settingsNewFileCardComponent = new ucSettingsNewFileCard(currentCardBox);
                //settingsNewFileCardComponent.SettingsNextFileCardEvent += BtnSettingsFinished_PageChanged;
                //content.Children.Add(settingsNewFileCardComponent);

                // opens mask for creating a new Project
                ucNewProject newProjectComponent = new ucNewProject(currentUser);
                newProjectComponent.NewProjectEvent += NewProjectComponent_NewProjectEvent;
                content.Children.Add(newProjectComponent);

                // jumps to Home screen (first page)
                ChangeMainContent(new ucHome(cardBoxes));
            }

            private void NewProjectComponent_NewProjectEvent(object sender, ucNewProject.NewProject e)
            {
                // ChangeMainContent(new ucNewProject(currentUser));
                ChangeMainContent(new ucSaved());
            }

            // Changes foreground of the main area
            public void ChangeMainContent(UIElement uIElement)
            {
                content.Children.Clear();
                sideBarGrid.Children.Clear();
                content.ColumnDefinitions.Clear();
                content.Children.Add(uIElement);

                if (uIElement is ucFileCardQuestion)
                {
                    (uIElement as ucFileCardQuestion).ChangeQuestionToAnswerEvent += BtnAnswer_PageChanged;
                }
                else if (uIElement is ucFileCardAnswer)
                {
                    (uIElement as ucFileCardAnswer).ChangeAnswerToQuestionEvent += BtnQuestion_PageChanged;
                }
                else if (uIElement is ucSettingsNewFileCard)
                {
                    (uIElement as ucSettingsNewFileCard).SettingsNextFileCardEvent += BtnSettingsNext_PageChanged;
                }
                else if (uIElement is ucSettingsNewFileCard)
                {
                    (uIElement as ucSettingsNewFileCard).SettingsNextFileCardEvent += BtnSettingsFinished_PageChanged;
                }
                else if (uIElement is ucHome)
                {
                    (uIElement as ucHome).ChangeCardBoxTrainingEvent += SignIn_ChangeCardBoxTraining;
                }
                else if (uIElement is ucNewProject)
                {
                    (uIElement as ucNewProject).NewProjectEvent += NewProjectComponent_NewProjectEvent;
                }
            }

            private void SignIn_ChangeCardBoxTraining(object sender, ChangeCardBoxTraining e)
            {
                currentCardBox = e.Target;
                topBarComponent.ChangeCurrentCardBox(currentCardBox);
                ChangeMainContent(new ucFileCardQuestion(e.Target));
                ChangeSideBar(new ucSideBar());
            }

            // Changes foreground of the side area
            public void ChangeSideBar(UIElement uIElement)
            {
                sideBarGrid.Children.Clear();
                if (uIElement is ucSettingsSideBar)
                {
                    ((ucSettingsSideBar)uIElement).ChangePageForEditingEvent += SideBarComponent_ChangePageForEditing;
                }
                else if (uIElement is ucSideBar)
                {
                    // todo ucSideBar ??
                }
                sideBarGrid.Children.Add(uIElement);
            }

            // Offers a choice of pages to show in the foreground
            private void TopBarComponent_ChangePage(object sender, ChangePage e)
            {
                switch (e.Target)
                {
                    case TargetPages.Home:
                        cardBoxes = cardBoxManager.GetCardBoxes(currentUser.UserId);
                        ChangeMainContent(new ucHome(cardBoxes));
                        break;
                    case TargetPages.Training:
                        ChangeMainContent(new ucFileCardQuestion(cardBoxes[2]));
                        ChangeSideBar(new ucSideBar());
                        break;
                    case TargetPages.Settings:
                        ChangeMainContent(new ucSettings());
                        ChangeSideBar(new ucSettingsSideBar());
                        break;
                    case TargetPages.NewProject:
                        ChangeMainContent(new ucNewProject(currentUser));
                        break;
                    default:
                        break;
                }
            }

            // switches back to Sign-In after having signed out
            private void Topbar_SignOut(object sender, EventArgs e)
            {
                SignIn signIn = new SignIn();
                signIn.Show();
                this.Close();
            }

            private void SideBarComponent_ChangePageForEditing(object sender, ChangePageForEditing e)
            {
                switch (e.Target)
                {
                    case TargetEditingPages.EditCardBox:
                        break;
                    case TargetEditingPages.EditRegister:
                        break;
                    case TargetEditingPages.EditFileCards:
                        ChangeMainContent(new ucSettingsNewFileCard(currentCardBox));
                        ChangeSideBar(new ucSettingsSideBar());
                        break;
                    case TargetEditingPages.ImportFile:
                        break;
                    case TargetEditingPages.ExportFile:
                        break;
                    default:
                        break;
                }
            }

            private void BtnAnswer_PageChanged(object sender, ChangeQuestionToAnswer e)
            {
                ChangeMainContent(new ucFileCardAnswer(currentCardBox));
                ChangeSideBar(new ucSideBar());
            }
            private void BtnQuestion_PageChanged(object sender, ChangeAnswerToQuestion e)
            {
                ChangeMainContent(new ucFileCardQuestion(currentCardBox));
                ChangeSideBar(new ucSideBar());
            }
            private void BtnSettingsNext_PageChanged(object sender, SettingsNextFileCard e)
            {
                ChangeMainContent(new ucSettingsNewFileCard(currentCardBox));
                ChangeSideBar(new ucSettingsSideBar());
            }
            private void BtnSettingsFinished_PageChanged(object sender, SettingsNextFileCard e)
            {
                ChangeMainContent(new ucSaved());
                ChangeSideBar(new ucSettingsSideBar());
            }

            // todo BtnSettingsFinished
            //private void Button_click(object sender, RoutedEventArgs e)
            //{
            //    ChooseButton(sender);
            //}

            //private void ChooseButton(object sender)
            //{
            //    ucSettingsNewFileCard settingsNewFileCardComponent = new ucSettingsNewFileCard(currentCardBox); //targetButton
            //    if (targetButton.Name == "btnSettingsNext")
            //    {
            //        settingsNewFileCardComponent.SettingsNextFileCardEvent += BtnSettingsNext_PageChanged;
            //    }
            //    else if (targetButton.Name == "btnSettingsFinished")
            //    {
            //        settingsNewFileCardComponent.SettingsNextFileCardEvent += BtnSettingsFinished_PageChanged;
            //    }
            //    content.Children.Add(settingsNewFileCardComponent);
            //}
        }
    }


﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace Lernsoftware
{
    /// <summary>
    /// Interaction logic for ucSettingsSideBar.xaml
    /// </summary>
    /// 
    public partial class ucSettingsSideBar : UserControl
    {
        public event EventHandler<ChangePageForEditing> ChangePageForEditingEvent;

        public ucSettingsSideBar()
        {
            InitializeComponent();
        }

        private void ChangePageForEditing_Click(object sender, RoutedEventArgs e)
        {
            TargetEditingPages editingTarget = (TargetEditingPages)Enum.Parse(typeof(TargetEditingPages), ((Button)sender).Name.Replace("btn", "").ToString());
            ChangePageForEditingEvent(this, new ChangePageForEditing(editingTarget));
        }

        public class ChangePageForEditing : EventArgs
        {
            public TargetEditingPages Target;

            public ChangePageForEditing(TargetEditingPages editingTarget)
            {
               Target = editingTarget;
            }
        }

        public enum TargetEditingPages
        {
            EditCardBox,
            EditRegister,
            EditFileCards,
            ImportFile,
            ExportFile
        }
    }
}

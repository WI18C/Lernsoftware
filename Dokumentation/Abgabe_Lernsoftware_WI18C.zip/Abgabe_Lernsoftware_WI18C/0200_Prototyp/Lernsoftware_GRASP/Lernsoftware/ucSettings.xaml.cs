﻿using System.Windows.Controls;

namespace Lernsoftware
{
    /// <summary>
    /// Interaction logic for ucSettings.xaml
    /// </summary>
    public partial class ucSettings : UserControl
    {
        public ucSettings()
        {
            InitializeComponent();
        }
    }
}

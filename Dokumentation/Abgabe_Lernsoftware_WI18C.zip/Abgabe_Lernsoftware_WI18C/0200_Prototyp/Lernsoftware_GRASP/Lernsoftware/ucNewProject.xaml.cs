﻿using System;
using System.Windows;
using System.Windows.Controls;
using Lernsoftware.Logic.CardboxAg;
using Lernsoftware.Logic.UserAg;


namespace Lernsoftware
{
    /// <summary>
    /// Interaction logic for ucNewProject.xaml
    /// </summary>
    public partial class ucNewProject : UserControl
    {
        ICardBoxManager cardBoxManager = new CardboxManager();
        public event EventHandler<NewProject> NewProjectEvent;
        private CardBox cardBox;
        private User currentUser;
        public ucNewProject(User user)
        {
            InitializeComponent();
            currentUser = user;
        }

        private void BtnSaveNewProject_Click(object sender, RoutedEventArgs e)
        {
            cardBox = new CardBox(txtCardBoxName.Text);
            cardBoxManager.SaveCardBox(cardBox, currentUser.UserId);
            NewProjectEvent(this, new NewProject());
        }

        public class NewProject : EventArgs
        {
             public NewProject()
            {
            }
        }

    }
}

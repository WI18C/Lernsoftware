﻿namespace GRASP
{
    partial class ucSideBar
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRegister1 = new System.Windows.Forms.Button();
            this.btnRegister2 = new System.Windows.Forms.Button();
            this.btnRegister3 = new System.Windows.Forms.Button();
            this.btnRegister4 = new System.Windows.Forms.Button();
            this.btnRegister5 = new System.Windows.Forms.Button();
            this.btnRegister6 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnRegister1
            // 
            this.btnRegister1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.btnRegister1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.btnRegister1.FlatAppearance.BorderSize = 0;
            this.btnRegister1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegister1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegister1.ForeColor = System.Drawing.Color.White;
            this.btnRegister1.Location = new System.Drawing.Point(3, 132);
            this.btnRegister1.Name = "btnRegister1";
            this.btnRegister1.Size = new System.Drawing.Size(190, 67);
            this.btnRegister1.TabIndex = 5;
            this.btnRegister1.Text = "REGISTER 1";
            this.btnRegister1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnRegister1.UseVisualStyleBackColor = false;
            // 
            // btnRegister2
            // 
            this.btnRegister2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.btnRegister2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.btnRegister2.FlatAppearance.BorderSize = 0;
            this.btnRegister2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegister2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegister2.ForeColor = System.Drawing.Color.White;
            this.btnRegister2.Location = new System.Drawing.Point(3, 205);
            this.btnRegister2.Name = "btnRegister2";
            this.btnRegister2.Size = new System.Drawing.Size(190, 67);
            this.btnRegister2.TabIndex = 6;
            this.btnRegister2.Text = "REGISTER 2";
            this.btnRegister2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnRegister2.UseVisualStyleBackColor = false;
            // 
            // btnRegister3
            // 
            this.btnRegister3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.btnRegister3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.btnRegister3.FlatAppearance.BorderSize = 0;
            this.btnRegister3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegister3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegister3.ForeColor = System.Drawing.Color.White;
            this.btnRegister3.Location = new System.Drawing.Point(3, 278);
            this.btnRegister3.Name = "btnRegister3";
            this.btnRegister3.Size = new System.Drawing.Size(190, 67);
            this.btnRegister3.TabIndex = 7;
            this.btnRegister3.Text = "REGISTER 3";
            this.btnRegister3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnRegister3.UseVisualStyleBackColor = false;
            // 
            // btnRegister4
            // 
            this.btnRegister4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.btnRegister4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.btnRegister4.FlatAppearance.BorderSize = 0;
            this.btnRegister4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegister4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegister4.ForeColor = System.Drawing.Color.White;
            this.btnRegister4.Location = new System.Drawing.Point(3, 351);
            this.btnRegister4.Name = "btnRegister4";
            this.btnRegister4.Size = new System.Drawing.Size(190, 67);
            this.btnRegister4.TabIndex = 8;
            this.btnRegister4.Text = "REGISTER 4";
            this.btnRegister4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnRegister4.UseVisualStyleBackColor = false;
            // 
            // btnRegister5
            // 
            this.btnRegister5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.btnRegister5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.btnRegister5.FlatAppearance.BorderSize = 0;
            this.btnRegister5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegister5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegister5.ForeColor = System.Drawing.Color.White;
            this.btnRegister5.Location = new System.Drawing.Point(3, 424);
            this.btnRegister5.Name = "btnRegister5";
            this.btnRegister5.Size = new System.Drawing.Size(190, 67);
            this.btnRegister5.TabIndex = 9;
            this.btnRegister5.Text = "REGISTER 5";
            this.btnRegister5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnRegister5.UseVisualStyleBackColor = false;
            // 
            // btnRegister6
            // 
            this.btnRegister6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.btnRegister6.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.btnRegister6.FlatAppearance.BorderSize = 0;
            this.btnRegister6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegister6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegister6.ForeColor = System.Drawing.Color.White;
            this.btnRegister6.Location = new System.Drawing.Point(3, 497);
            this.btnRegister6.Name = "btnRegister6";
            this.btnRegister6.Size = new System.Drawing.Size(190, 67);
            this.btnRegister6.TabIndex = 10;
            this.btnRegister6.Text = "REGISTER 6";
            this.btnRegister6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnRegister6.UseVisualStyleBackColor = false;
            // 
            // ucSideBar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.Controls.Add(this.btnRegister6);
            this.Controls.Add(this.btnRegister5);
            this.Controls.Add(this.btnRegister4);
            this.Controls.Add(this.btnRegister3);
            this.Controls.Add(this.btnRegister2);
            this.Controls.Add(this.btnRegister1);
            this.Name = "ucSideBar";
            this.Size = new System.Drawing.Size(262, 646);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnRegister1;
        private System.Windows.Forms.Button btnRegister2;
        private System.Windows.Forms.Button btnRegister3;
        private System.Windows.Forms.Button btnRegister4;
        private System.Windows.Forms.Button btnRegister5;
        private System.Windows.Forms.Button btnRegister6;
    }
}

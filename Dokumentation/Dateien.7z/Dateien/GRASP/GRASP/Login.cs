﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GRASP
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void TopBar_Paint(object sender, PaintEventArgs e)
        {

        }

        private void BtnSignIn_Click(object sender, EventArgs e)
        {
            string userName = txtUserName.Text;
            string password = txtPassword.Text;

            if(userName == "system" && password == "system")
            {
                BaseScreen home = new BaseScreen();
                home.Show();
            }
            else
            {
                MessageBox.Show("User Name or Password incorrect. Please try again.");
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;

namespace Lernsoftware.Logic.CardboxAg
{
    public class CardboxManager : ICardBoxManager
    {
        public void SaveCardBox(CardBox cardBox, int userID)
        {
            using (var database = Config.GetDbConnection())
            {
                string commandstring = "INSERT INTO `cardbox` (`cardbox_ID`, `cardbox_name`, `user_ID`) " +
             "VALUES(NULL, '" + cardBox.CardBoxName + "' , " + userID + "); ";
                try
                {
                    database.Open();
                    MySqlCommand command = new MySqlCommand(commandstring, database);
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    database.Close();
                }                             
            }
        }
        public void DeleteCardBox()
        {
            throw new NotImplementedException();
        }
        public List<CardBox> GetCardBoxes(int userID)
        {
            using (var database = Config.GetDbConnection())
            {
                string commandstring = "SELECT cardbox_ID, cardbox_name " +
                                       "FROM `cardbox` " +
                                       "WHERE user_ID = " + userID + ";";
                try
                {
                    database.Open();
                    MySqlCommand command = new MySqlCommand(commandstring, database);
                    MySqlDataReader reader = command.ExecuteReader();
                    if (reader.HasRows)
                    {
                        List<CardBox> cardBoxes = new List<CardBox>();
                        while (reader.Read())
                        {
                            CardBox cardBox = new CardBox(reader.GetInt32(0), reader.GetString(1));
                            cardBoxes.Add(cardBox);
                        }
                        return cardBoxes;
                    }
                    else
                        return null;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    database.Close();
                }
            }
        }
        public void UpdateCardBox(CardBox originalCardBox, string cardBoxName)
        {
            using (var database = Config.GetDbConnection())
            {
                try
                {
                    string commandstring = "UPDATE `cardbox` SET `cardbox_name` = '" + cardBoxName + "' WHERE `cardbox`.`cardbox_ID` = " + originalCardBox.CardBoxId + ";";
                    MySqlCommand command = new MySqlCommand(commandstring, database);
                    database.Open();
                    command.ExecuteNonQuery();
                    originalCardBox.CardBoxName = cardBoxName;
                    database.Close();
                }
                catch (Exception)
                {
                    database.Close();
                    throw;
                }
            }
        }
    }
}

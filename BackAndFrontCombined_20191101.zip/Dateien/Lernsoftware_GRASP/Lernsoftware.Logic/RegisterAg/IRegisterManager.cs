﻿using System;
using System.Collections.Generic;
using System.Text;
using Lernsoftware.Logic.CardboxAg;

namespace Lernsoftware.Logic.RegisterAg
{
    public interface IRegisterManager
    {
        void UpdateRegister();
        void SaveRegister();
        void AddRegister(CardBox cardBox);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using Lernsoftware.Logic.CardboxAg;
using MySql.Data.MySqlClient;

namespace Lernsoftware.Logic.RegisterAg
{
    public class RegisterManager : IRegisterManager
    {
        // todo aktualisiert Register nach Beendigung des Trainings und dem Erstellen neuer FileCards
        public void UpdateRegister() 
        {         
                
        }

        public void SaveRegister()
        {
          // todo SaveRegisterInDB
        }

        // Neues Register wird hinzugefügt -> max. Anzahl = 6
        public void AddRegister(CardBox cardBox)
        {
            // todo AddRegister to CardBox
            //connection.saveRegisterInDB(cardBox.CardBoxId, name);
        }

    }
}

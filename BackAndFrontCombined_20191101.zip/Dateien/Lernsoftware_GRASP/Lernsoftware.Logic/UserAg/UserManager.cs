﻿using System;
using MySql.Data.MySqlClient;

namespace Lernsoftware.Logic.UserAg
{
    public class UserManager : IUserManager
    {
        public void ChangePassword(User user, string newPwd)
        {
            using (var database = Config.GetDbConnection())
            {
                string commandstring = "UPDATE `user` " +
                                       "SET `user_password` = '" + newPwd + "' " +
                                       "WHERE `user`.`user_ID` = " + user.UserId + ";";
                try
                {
                    database.Open();
                    MySqlCommand command = new MySqlCommand(commandstring, database);
                    command.ExecuteNonQuery();
                    user.Password = newPwd;
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    database.Close();
                }
            }
        }
        public void ChangeUsername(User user, string newName)
        {
            using (var database = Config.GetDbConnection())
            {
                string commandstring = "UPDATE `user` " +
                                            "SET `user_name` = '" + newName + "' " +
                                            "WHERE `user`.`user_ID` = " + user.UserId + ";";
                try
                {
                    database.Open();
                    MySqlCommand command = new MySqlCommand(commandstring, database);
                    command.ExecuteNonQuery();
                    user.Username = newName;
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    database.Close();
                }
            }
        }
        public Boolean DeleteUser(string name)
        {

            return true;
        }
        public User LoginUser(string name, string pwd)
        {
            using (var database = Config.GetDbConnection())
            {
                string commandstring = "SELECT user_ID, user_name, user_password " +
                       "FROM `user` " +
                       "WHERE user_name = '" + name + "';";
                try
                {
                    database.Open();
                    MySqlCommand command = new MySqlCommand(commandstring, database);
                    MySqlDataReader reader = command.ExecuteReader();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            if (reader.GetString(2) == pwd)
                            {
                                User user = new User(reader.GetInt32(0), reader.GetString(1));
                                return user;
                            }
                        }
                    }
                    else
                        return null;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    database.Close();
                }
            }
            return null;
        }
        public User NewUser(string name, string pwd)
        {
            using (var database = Config.GetDbConnection())
            {
                User user = new User(name);
                string commandstring = "INSERT INTO `user` (`user_name`, `user_password`) " +
                                       "VALUES ('" + name + "', '" + pwd + "')";
                MySqlCommand command = new MySqlCommand(commandstring, database);
                try
                {
                    database.Open();
                    command.ExecuteNonQuery();
                    commandstring = "SELECT user_ID " +
                       "FROM `user` " +
                       "WHERE user_name = '" + name + "';";
                    command = new MySqlCommand(commandstring, database);
                    MySqlDataReader reader = command.ExecuteReader();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            user.UserId = reader.GetInt32(0);
                            return user;
                        }
                    }
                    return null;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    database.Close();
                }
            }
        }

        public int GetUserId(string name)
        {
            using (var database = Config.GetDbConnection())
            {
                string commandstring = "SELECT user_ID " +
                       "FROM `user` " +
                       "WHERE user_name = '" + name + "';";
                try
                {
                    database.Open();
                    MySqlCommand command = new MySqlCommand(commandstring, database);
                    MySqlDataReader reader = command.ExecuteReader();
                    if (reader.HasRows)
                    {
                        return reader.GetInt32(0);
                    }                
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    database.Close();
                }
            }
            return 0;
        }
    }
    //user.CardBoxList = connection.loadCardBoxesInUserFromDB(user.UserId);
    //    try
    //    {
    //        user.CardBoxList = connection.loadCardBoxesInUserFromDB(user.UserId);
    //        return user;
    //    }

    //    catch (Exception ex)
    //    {
    //        return null;
    //    }


}

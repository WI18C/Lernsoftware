﻿using MySql.Data.MySqlClient;


namespace Lernsoftware.Logic
{
    public static class Config
    {
        private static readonly string user = "root";
        private static readonly string password = "";
        public static MySqlConnection GetDbConnection()
        {
            var connection = new MySqlConnection();
            MySqlConnectionStringBuilder builder = new MySqlConnectionStringBuilder
            {
                Server = "localhost",
                Database = "lernsoftwaredb",
                UserID = user,
                Password = password
            };
            connection.ConnectionString = builder.GetConnectionString(false);// "SERVER=localhost; DATABASE=lernsoftwaredb; UID=" + user + "; PASSWORD=" + password + ";";
            return connection;
        }
    }
}

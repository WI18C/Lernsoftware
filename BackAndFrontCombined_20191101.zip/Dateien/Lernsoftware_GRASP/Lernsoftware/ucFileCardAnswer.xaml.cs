﻿using System;
using System.Windows.Controls;
using Lernsoftware.Logic.CardboxAg;

namespace Lernsoftware
{
    /// <summary>
    /// Interaction logic for ucFileCardAnswer.xaml
    /// </summary>
    public partial class ucFileCardAnswer : UserControl
    {
        public EventHandler<ChangeAnswerToQuestion> ChangeAnswerToQuestionEvent;
        public ucFileCardAnswer(CardBox cardBox)
        {
            InitializeComponent();
            lblCardBoxNameAnswer.Content = cardBox.CardBoxName.ToUpper() + " - train your brain";
        }

        private void BtnQuestion_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            ChangeAnswerToQuestionEvent(this, new ChangeAnswerToQuestion());
           // txtAnswer.Text; // todo in Oberfläche einbinden
        }

        public class ChangeAnswerToQuestion : EventArgs
        {
            // todo showQuestion();
        }
    }
}

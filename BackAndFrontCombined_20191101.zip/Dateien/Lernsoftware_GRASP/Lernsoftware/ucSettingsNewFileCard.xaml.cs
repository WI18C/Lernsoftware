﻿using System;
using System.Windows;
using System.Windows.Controls;
using Lernsoftware.Logic.CardboxAg;
using Lernsoftware.Logic.FileCardAg;

namespace Lernsoftware
{
    /// <summary>
    /// Interaction logic for ucSettingsNewFileCard.xaml
    /// </summary>
    public partial class ucSettingsNewFileCard : UserControl
    {
        private IFileCardManager fileCardManager = new FileCardManager();
        public EventHandler<SettingsNextFileCard> SettingsNextFileCardEvent;
        private FileCard fileCard;
        private CardBox currentCardBox;

        public ucSettingsNewFileCard(CardBox cardBox)
        {
            InitializeComponent();
            currentCardBox = cardBox;
            if (currentCardBox != null)
            {
                lblSettings.Content = cardBox.CardBoxName.ToUpper() + " - add new File Cards";
            }
        }

        //public ucSettingsNewFileCard(CardBox cardBox, Button targetButton)
        //{
        //    InitializeComponent();
        //    currentCardBox = cardBox;
        //    if (currentCardBox != null)
        //    {
        //        lblSettings.Content = cardBox.CardBoxName.ToUpper() + " - add new File Cards";
        //    }
        //    this.targetButton = targetButton;
        //}

        private void BtnSettingsNext_Click(object sender, RoutedEventArgs e)
        {
            fileCard = new FileCard(txtPutQuestion.Text, txtPutAnswer.Text);
            fileCardManager.SaveSingleFileCardinDB(fileCard, 1);
            SettingsNextFileCardEvent(this, new SettingsNextFileCard());
        }
        private void BtnSettingsFinished_Click(object sender, RoutedEventArgs e)
        {
            fileCard = new FileCard(txtPutQuestion.Text, txtPutAnswer.Text);
            fileCardManager.SaveSingleFileCardinDB(fileCard, 1);
            SettingsNextFileCardEvent(this, new SettingsNextFileCard());
        }

        public class SettingsNextFileCard : EventArgs
        {
            public Button targetButton;
            public SettingsNextFileCard()
            {
            }
        }
    }
}

﻿using System;
using System.Windows;
using System.Windows.Controls;
using Lernsoftware.Logic.CardboxAg;

namespace Lernsoftware
{
    /// <summary>
    /// Interaction logic for ucFileCardQuestion.xaml
    /// </summary>
    /// 


    public partial class ucFileCardQuestion : UserControl
    {
        public event EventHandler<ChangeQuestionToAnswer> ChangeQuestionToAnswerEvent;

        public ucFileCardQuestion(CardBox cardBox)
        {
            InitializeComponent();
            lblCardBoxNameQuestion.Content = cardBox.CardBoxName.ToUpper() + " - train your brain";
        }

        private void BtnAnswer_Click(object sender, RoutedEventArgs e)
        {
            ChangeQuestionToAnswerEvent(this, new ChangeQuestionToAnswer());
        }

        public class ChangeQuestionToAnswer : EventArgs
        {
            public CardBox Target;
            public ChangeQuestionToAnswer()
            {
                // todo showAnswer();
            }
        }
    }
}

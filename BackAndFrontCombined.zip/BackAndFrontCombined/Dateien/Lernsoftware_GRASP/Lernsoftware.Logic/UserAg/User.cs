﻿using System;
using System.Collections.Generic;
using System.Linq;
using Lernsoftware.Logic.CardboxAg;
using Logic;

namespace Lernsoftware.Logic.UserAg
{
    public class User
    {
        static MySQLDao connection = new MySQLDao();

        public int UserId { get;  set; }
        public string Username { get; set; }  
        public string Password { get; set; }
        internal List<CardBox> CardBoxList { get; set; }
        public User()
        {
        }
        public User(string username)
        {
            Username = username;
        }
        public User(int userID, string username)
        {
            UserId = userID;
            Username = username;        
        }
                       
        public override bool Equals(object obj)
        {
            if (obj == null || GetType() != obj.GetType())
            {
                return false;
            }

            User user = (User)obj;
            if (user.UserId == this.UserId
                && user.Username == this.Username)
            {
                return true;
            }
            else
                return false;
        }
    }
    //Ändert Cardbox-Namen
    /* public Boolean changeCardBox(User user, string alt, string neu)
     {
         List<CardBox> cardBoxes = connection.loadCardBoxesInUserFromDB(user.UserId);
         CardBox cardbox = (from c in cardBoxes
                            where c.CardBoxName == alt
                            select c).FirstOrDefault();
         if (cardbox == null)
         {
             return false;
         }
         else
         {
             connection.updateCardboxInDB(cardbox, neu);
             return true;
         }
     }
             public void createNewCardBox(int UserId, string name)
         {
             connection.saveCardboxInDB(UserId, name);
         }
         public Boolean deleteCardBox(string name)
         {
             //Datenbank
             return true; 
         }
         public CardBox getCardboxById(int cardboxId,int userId)
         {
             List<CardBox> cardBoxes = connection.loadCardBoxesInUserFromDB(userId);
             CardBox cardbox = (from c in cardBoxes
                                where c.CardBoxId == cardboxId
                                select c).FirstOrDefault(); 
             return cardbox; 
         }*/
}

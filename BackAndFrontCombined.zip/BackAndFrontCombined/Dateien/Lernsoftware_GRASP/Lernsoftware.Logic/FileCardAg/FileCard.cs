﻿using System.Collections.Generic;

namespace Lernsoftware.Logic.FileCardAg
{
    public class FileCard
    {
        public int FileCardId { get; set; }
        public static int IdCounter { get; set; } = 1;
        public string Question { get; set; }
        public string Answer { get; set; }
        #region For later statistics
        public int TryCounter { get; set; } = 0;
        public int WrongCounter { get; set; } = 0;
        public int RightCounter { get; set; } = 0;
        #endregion
        public FileCard(string question, string answer)
        {
            FileCardId = IdCounter;
            IdCounter++;
            Question = question;
            Answer = answer;
        }
        public FileCard(int fileCardId, string question, string answer)
        {
            FileCardId = fileCardId;
            Question = question;
            Answer = answer;
        }
        public override bool Equals(object obj)
        {
            if (obj == null || GetType() != obj.GetType())
            {
                return false;
            }
            FileCard card = (FileCard)obj;
            if (card.FileCardId == this.FileCardId
                && card.Question == this.Question
                && card.Answer == this.Answer)
            {
                return true;
            }
            else
                return false;
        }
        public override int GetHashCode()
        {
            var hashCode = 32845788;
            hashCode = hashCode * -1521134295 + FileCardId.GetHashCode();
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Question);
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Answer);
            return hashCode;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;

namespace Lernsoftware.Logic.FileCardAg
{
    public class FileCardManager : IFileCardManager
    {
        public void SaveSingleFileCardinDB(FileCard fileCard, int registerID)
        {
            using (var database = Config.GetDbConnection())
            {
                string commandstring = "INSERT INTO `filecard` (`fc_ID`, `register_ID`, `fc_question`, `fc_answer`) " +
                             "VALUES(NULL, " + registerID + ", '" + fileCard.Question + "', '" + fileCard.Answer + "');";
                try
                {
                    database.Open();
                    MySqlCommand command = new MySqlCommand(commandstring, database);
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    database.Close();
                }
            }
        }
        public List<FileCard> LoadFilecardsInResgisterFromDB(int registerID)
        {
            using (var database = Config.GetDbConnection())
            {
                string commandstring = "SELECT * FROM `filecard` WHERE filecard.register_ID = " + registerID + ";";
                try
                {
                    database.Open();
                    MySqlCommand command = new MySqlCommand(commandstring, database);
                    MySqlDataReader reader = command.ExecuteReader();
                    if (reader.HasRows)
                    {
                        List<FileCard> fileCards = new List<FileCard>();
                        while (reader.Read())
                        {
                            FileCard fileCard = new FileCard(reader.GetInt16(0), reader.GetString(2), reader.GetString(3));
                            fileCards.Add(fileCard);
                        }
                        database.Close();
                        return fileCards;
                    }
                }
                catch (Exception ex)
                {
                    database.Close();
                    throw ex;
                }
            }
            return null;
        }
        public void UpdateFileCardInDB(FileCard OriginalfileCard, bool isQuestion, string changedText)
        {
            using (var database = Config.GetDbConnection())
            {
                string commandstring = isQuestion ?
                    "UPDATE `filecard` SET `fc_question` = '" + changedText + "' WHERE `filecard`.`fc_ID` = " + OriginalfileCard.FileCardId + ";" :
                    "UPDATE `filecard` SET `fc_answer` = '" + changedText + "' WHERE `filecard`.`fc_ID` = " + OriginalfileCard.FileCardId + ";";
                try
                {
                    MySqlCommand command = new MySqlCommand(commandstring, database);
                    database.Open();
                    command.ExecuteNonQuery();
                    if (isQuestion)
                    {
                        OriginalfileCard.Question = changedText;
                    }
                    else
                    {
                        OriginalfileCard.Answer = changedText;
                    }
                    database.Close();
                }
                catch (Exception)
                {
                    throw;
                }
            }
        }
        public void UpdateFileCardInDB(FileCard OriginalfileCard, string changeQuestion, string changedAnswer)
        {
            using (var database = Config.GetDbConnection())
            {
                try
                {
                    string commandstring = "UPDATE `filecard` SET `fc_question` = '" + changeQuestion + "', `fc_answer` = '" + changedAnswer + "' WHERE `filecard`.`fc_ID` = " + OriginalfileCard.FileCardId + ";";
                    MySqlCommand command = new MySqlCommand(commandstring, database);
                    database.Open();
                    command.ExecuteNonQuery();
                    OriginalfileCard.Question = changeQuestion;
                    OriginalfileCard.Answer = changedAnswer;
                    database.Close();
                }
                catch (Exception)
                {
                    database.Close();
                    throw;
                }
            }
        }
        public void MoveFileCardInRegister(int registerId, int fileCardId)
        {
            using (var database = Config.GetDbConnection())
            {
                string commandstring = "UPDATE `filecard` SET `register_ID` = '" + registerId + "' WHERE `filecard`.`fc_ID` = " + fileCardId + ";";
                try
                {
                    database.Open();
                    MySqlCommand command = new MySqlCommand(commandstring, database);
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    database.Close();
                    throw ex;
                }
            }
        }
    }
}

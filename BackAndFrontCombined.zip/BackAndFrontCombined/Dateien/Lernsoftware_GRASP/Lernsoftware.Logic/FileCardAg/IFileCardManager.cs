﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lernsoftware.Logic.FileCardAg
{
    public interface IFileCardManager
    {
        void SaveSingleFileCardinDB(FileCard fileCard, int registerID);
        List<FileCard> LoadFilecardsInResgisterFromDB(int registerID);
        void UpdateFileCardInDB(FileCard OriginalfileCard, bool isQuestion, string changedText);
        void UpdateFileCardInDB(FileCard OriginalfileCard, string changeQuestion, string changedAnswer);
        void MoveFileCardInRegister(int registerId, int fileCardId);
    }
}

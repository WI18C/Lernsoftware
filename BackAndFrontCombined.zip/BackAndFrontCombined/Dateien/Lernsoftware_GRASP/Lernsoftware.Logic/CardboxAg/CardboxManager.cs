﻿using System;
using System.Collections.Generic;
using System.Text;
using Logic;
using MySql.Data.MySqlClient;

namespace Lernsoftware.Logic.CardboxAg
{
    public class CardboxManager : ICardBoxManager
    {
        public CardBox CreateCardBox()
        {
            throw new NotImplementedException();
        }
        public void DeleteCardBox()
        {
            throw new NotImplementedException();
        }
        public List<CardBox> GetCardBoxes(int userID)
        {
            using (var database = Config.GetDbConnection())
            {
                string commandstring = "SELECT cardbox_ID, cardbox_name " +
                                       "FROM `cardbox` " +
                                       "WHERE user_ID = " + userID + ";";
                try
                {
                    database.Open();
                    MySqlCommand command = new MySqlCommand(commandstring, database);
                    MySqlDataReader reader = command.ExecuteReader();
                    if (reader.HasRows)
                    {
                        List<CardBox> cardBoxes = new List<CardBox>();
                        while (reader.Read())
                        {
                            CardBox cardBox = new CardBox(reader.GetInt32(0), reader.GetString(1));
                            cardBoxes.Add(cardBox);
                        }
                        return cardBoxes;
                    }
                    else
                        return null;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    database.Close();
                }
            }
        }
        public CardBox UpdateCardBox()
        {
            throw new NotImplementedException();
        }
    }
}

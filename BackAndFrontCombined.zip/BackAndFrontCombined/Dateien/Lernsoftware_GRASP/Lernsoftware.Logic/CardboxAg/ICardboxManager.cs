﻿using Logic;
using System;
using System.Collections.Generic;
using System.Text;

namespace Lernsoftware.Logic.CardboxAg
{
    public interface ICardBoxManager
    {
        List<CardBox> GetCardBoxes(int userID);



        CardBox CreateCardBox();
        CardBox UpdateCardBox();
        void DeleteCardBox();
    }
}

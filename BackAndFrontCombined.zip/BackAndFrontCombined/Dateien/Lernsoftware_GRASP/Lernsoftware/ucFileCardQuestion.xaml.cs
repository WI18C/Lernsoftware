﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Lernsoftware.Logic.CardboxAg;

namespace Lernsoftware
{
    /// <summary>
    /// Interaction logic for ucFileCardQuestion.xaml
    /// </summary>
    /// 


    public partial class ucFileCardQuestion : UserControl
    {
        public EventHandler<ChangeQuestionToAnswer> ChangeQuestionToAnswerEvent ;

        public ucFileCardQuestion(CardBox cardBox)
        {
            InitializeComponent();
            lblCardBoxName.Content = cardBox.CardBoxName;
            
        }

        private void BtnAnswer_Click(object sender, RoutedEventArgs e)
        {
            ChangeQuestionToAnswerEvent(this, new ChangeQuestionToAnswer());
        }

        public class ChangeQuestionToAnswer : EventArgs
        {
            public ChangeQuestionToAnswer()
            {
                MessageBox.Show("ChangeQuestionToAnswer");
               // showAnswer();
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lernsoftware
{
    /// <summary>
    /// Interaction logic for ucSettingsSideBar.xaml
    /// </summary>
    /// 
    public partial class ucSettingsSideBar : UserControl
    {
        public event EventHandler<ChangePageForEditing> ChangePageForEditingEvent;

        public ucSettingsSideBar()
        {
            InitializeComponent();
        }

        private void ChangePageForEditing_Click(object sender, RoutedEventArgs e)
        {
            TargetEditingPages editingTarget = (TargetEditingPages)Enum.Parse(typeof(TargetEditingPages), ((Button)sender).Name.Replace("btn", "").ToString());
            ChangePageForEditingEvent(this, new ChangePageForEditing(editingTarget));
        }

        public class ChangePageForEditing : EventArgs
        {
            public TargetEditingPages Target;

            public ChangePageForEditing(TargetEditingPages editingTarget)
            {
               Target = editingTarget;
            }
        }

        public enum TargetEditingPages
        {
            EditCardBox,
            EditRegister,
            EditFileCards,
            ImportFile,
            ExportFile
        }
    }
}

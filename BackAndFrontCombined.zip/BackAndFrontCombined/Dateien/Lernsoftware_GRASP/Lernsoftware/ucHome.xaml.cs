﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Lernsoftware.Logic.CardboxAg;
using static Lernsoftware.ucNewProject;

namespace Lernsoftware
{
    /// <summary>
    /// Interaction logic for ucHome.xaml
    /// </summary>
    public partial class ucHome : UserControl
    {
        private List<CardBox> cardBoxes;
        public event EventHandler<ChangeCardBoxTraining> ChangeCardBoxTraining;
        public ucHome(List<CardBox> data)
        {
            InitializeComponent();
            cardBoxes = data;

            var row = 0;
            var col = 0;
            foreach (var cardBox in cardBoxes)
            {
                var button = addButton(cardBox);
                Grid.SetColumn(button, col);
                Grid.SetRow(button, row);
                RegisterGrid.Children.Add(button);
                col = col + 1;
                if (col >= 4)
                {
                    col = 0;
                    row = row + 1;
                }
            }
        }

        Button addButton(CardBox cardBox)
        {
            Button projectButton = new Button();
            projectButton.Name =$"btn_{cardBox.CardBoxId.ToString()}";
            projectButton.Content = cardBox.CardBoxName;
            projectButton.FontSize = 18;
            projectButton.Width = 178;
            projectButton.Height = 178;
            projectButton.Background = Brushes.White;
            projectButton.Foreground = new SolidColorBrush(Color.FromRgb(112, 48, 160));
            projectButton.BorderBrush = new SolidColorBrush(Color.FromRgb(112, 48, 160));
            projectButton.BorderThickness = new Thickness(3);
            projectButton.Click += ProjectButton_Click;
            return projectButton;
        }

        private void ProjectButton_Click(object sender, RoutedEventArgs e)
        {
            var item = cardBoxes.Find(c=>c.CardBoxId==Convert.ToInt32((sender as Button).Name.Split('_')[1]));
           ChangeCardBoxTraining.Invoke(this, new ChangeCardBoxTraining(item));
        }
    }
    public class ChangeCardBoxTraining : EventArgs
    {
        public CardBox Target;

        public ChangeCardBoxTraining(CardBox cardBox)
        {
            Target = cardBox;
        }
    }
}

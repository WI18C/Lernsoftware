﻿using System;
using System.Windows;
using System.Windows.Controls;
using Lernsoftware.Logic.CardboxAg;
using Lernsoftware.Logic.FileCardAg;

namespace Lernsoftware
{
    /// <summary>
    /// Interaction logic for ucSettingsNewFileCard.xaml
    /// </summary>
    public partial class ucSettingsNewFileCard : UserControl
    {
        private IFileCardManager fileCardManager = new FileCardManager();
        public EventHandler<SettingsNextFileCard> SettingsNextFileCardEvent;
        private FileCard fileCard;
        private CardBox currentCardBox;
        public ucSettingsNewFileCard(CardBox cardBox)
        {
            InitializeComponent();
            currentCardBox = cardBox;
            if (currentCardBox != null)
            {
                txtPutAnswer.Text = currentCardBox.CardBoxName;
            }
        }

        private void BtnSettingsNext_Click(object sender, RoutedEventArgs e)
        {
            fileCard = new FileCard(txtPutQuestion.Text, txtPutAnswer.Text);
            fileCardManager.SaveSingleFileCardinDB(fileCard, 1);
            SettingsNextFileCardEvent(this, new SettingsNextFileCard());
        }

        public class SettingsNextFileCard : EventArgs
        {

            public SettingsNextFileCard()
            {
                MessageBox.Show("SettingsNextFileCard");
                // save FileCard();
                // createNewFileCard();
            }
        }
    }
}

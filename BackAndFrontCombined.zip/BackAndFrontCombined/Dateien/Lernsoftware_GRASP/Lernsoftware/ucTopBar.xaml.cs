﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Lernsoftware.Logic.CardboxAg;

namespace Lernsoftware
{
    /// <summary>
    /// Interaction logic for ucTopBar.xaml
    /// </summary>
    public partial class ucTopBar : UserControl
    {
        public event EventHandler SignOut;
        public event EventHandler<ChangePage> ChangePageEvent;
        private CardBox cardBox = null;

        public ucTopBar(CardBox data)
        {
            InitializeComponent();
            cardBox = data;
            if (this.cardBox == null)
            {
                btnSettings.Visibility = Visibility.Hidden;
                btnTraining.Visibility = Visibility.Hidden;
            }
            else
            {
                btnSettings.Visibility = Visibility.Visible;
                btnTraining.Visibility = Visibility.Visible;
            }
        }

        private void BtnSignOut_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Good job! See you again soon.");
            SignOut(this, null);
        }

        private void ChangePageTo_Click(object sender, RoutedEventArgs e)
        {
            TargetPages target = (TargetPages)Enum.Parse(typeof(TargetPages), ((Button)sender).Name.Replace("btn", "").ToString());
            if(target!= TargetPages.Home && target!= TargetPages.NewProject)
            {
                if (cardBox != null )
                {
                    ChangePageEvent(this, new ChangePage(target));
                }
                else
                {
                    MessageBox.Show("Please selecte a card box first");
                }
            }
            else
            {
                ChangePageEvent(this, new ChangePage(target));
            }
            
        }

        public void ChangeCurrentCardBox(CardBox cardBox)
        {
            this.cardBox = cardBox;
            if (this.cardBox == null)
            {
                btnSettings.Visibility = Visibility.Hidden;
                btnTraining.Visibility = Visibility.Hidden;
            }
            else
            {
                btnSettings.Visibility = Visibility.Visible;
                btnTraining.Visibility = Visibility.Visible;
            }
        }

        public class ChangePage : EventArgs
        {
            public TargetPages Target;

            public ChangePage(TargetPages target)
            {
                Target = target;
            }
        }
        public enum TargetPages
        {
            Home,
            Training,
            Settings,
            NewProject
        }
    }
}

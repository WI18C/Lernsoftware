﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static Lernsoftware.ucTopBar;
using static Lernsoftware.ucSettingsSideBar;
using static Lernsoftware.ucFileCardQuestion;
using static Lernsoftware.ucFileCardAnswer;
using static Lernsoftware.ucSideBar;
using static Lernsoftware.ucSettingsNewFileCard;
using static Lernsoftware.ucHome;
using Logic;
using Lernsoftware.Logic.FileCardAg;
using Lernsoftware.Logic.UserAg;
using Lernsoftware.Logic.CardboxAg;

namespace Lernsoftware
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class SignIn : Window
    {
        public static bool UserIsLoggedIn = false;
        // Manager
        private IUserManager userManager = new UserManager();
        private ICardBoxManager cardBoxManager = new CardboxManager();
        // Persistent Data
        private CardBox currentCardBox = null;
        private List<CardBox> cardBoxes;
        ucTopBar topBarComponent;


        public SignIn()
        {
            InitializeComponent();
        }

        private void BtnSignIn_Click(object sender, RoutedEventArgs e)
        {
            User user = userManager.LoginUser(txtUserName.Text, txtPassword.Password);
            if (user != null)
            {
                cardBoxes = cardBoxManager.GetCardBoxes(user.UserId);
                ActivateSignedInMode();
            }
            else
                MessageBox.Show("User Name or Password incorrect. Please try again.");
        }

        private void BtnRegister_Click(object sender, RoutedEventArgs e)
        {
            var pwd = txtRegisterPassword.Password;
            if (pwd == txtRegisterRepeat.Password)
            {
                User user = userManager.NewUser(txtRegisterUserName.Text, txtRegisterPassword.Password);
                if (user != null)
                {
                    ActivateSignedInMode();
                }
                else
                    MessageBox.Show("User Name or Password incorrect. Please try again.");
            }
            else
            {
                MessageBox.Show("Password repetition incorrect. Please try again.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public void ActivateSignedInMode()
        {
            UserIsLoggedIn = true;

            // adds navigation into Topbar
            topBarComponent = new ucTopBar(currentCardBox);
            topBarComponent.ChangePageEvent += TopBarComponent_ChangePage;
            topBarComponent.SignOut += Topbar_SignOut;
            topBar.Children.Add(topBarComponent);

            // adds side navigation
            ucSettingsSideBar sideBarComponent = new ucSettingsSideBar();
            sideBarComponent.ChangePageForEditingEvent += SideBarComponent_ChangePageForEditing;
            sideBarGrid.Children.Add(sideBarComponent);

            // sideBarComponentRegisters
            ucSideBar sideBarComponentRegisters = new ucSideBar();

            // switches FileCards from Question to Answer
            ucFileCardQuestion fileCardQuestionComponent = new ucFileCardQuestion(cardBoxes[0]);
            fileCardQuestionComponent.ChangeQuestionToAnswerEvent += BtnAnswer_PageChanged;
            content.Children.Add(fileCardQuestionComponent);

            // createNewFileCard by using Next-Button
            ucSettingsNewFileCard settingsNewFileCardComponent = new ucSettingsNewFileCard(currentCardBox);
            settingsNewFileCardComponent.SettingsNextFileCardEvent += BtnSettingsNext_PageChanged;
            content.Children.Add(settingsNewFileCardComponent);

            // jumps to Home screen (first page)
            ChangeMainContent(new ucHome(cardBoxes));
        }

        // Changes foreground of the main area
        public void ChangeMainContent(UIElement uIElement)
        {
            content.Children.Clear();
            sideBarGrid.Children.Clear();
            content.ColumnDefinitions.Clear();
            content.Children.Add(uIElement);

            if (uIElement is ucFileCardQuestion)
            {
                (uIElement as ucFileCardQuestion).ChangeQuestionToAnswerEvent += BtnAnswer_PageChanged;
            }
            else if (uIElement is ucSettingsNewFileCard)
            {
                (uIElement as ucSettingsNewFileCard).SettingsNextFileCardEvent += BtnSettingsNext_PageChanged;
            }
            else if (uIElement is ucHome)
            {
                (uIElement as ucHome).ChangeCardBoxTraining += SignIn_ChangeCardBoxTraining; ;
            }

        }

        private void SignIn_ChangeCardBoxTraining(object sender, ChangeCardBoxTraining e)
        {
            currentCardBox = e.Target;
            topBarComponent.ChangeCurrentCardBox(currentCardBox);
            ChangeMainContent(new ucFileCardQuestion(e.Target));
            ChangeSideBar(new ucSideBar());
        }

        // Changes foreground of the side area
        public void ChangeSideBar(UIElement uIElement)
        {
            sideBarGrid.Children.Clear();
            if (uIElement is ucSettingsSideBar)
            {
                ((ucSettingsSideBar)uIElement).ChangePageForEditingEvent += SideBarComponent_ChangePageForEditing;
            }
            else if (uIElement is ucSideBar)
            {

            }



            sideBarGrid.Children.Add(uIElement);
        }

        // Offers a choice of pages to show in the foreground
        private void TopBarComponent_ChangePage(object sender, ChangePage e)
        {
            switch (e.Target)
            {
                case TargetPages.Home:
                    ChangeMainContent(new ucHome(cardBoxes));
                    break;
                case TargetPages.Training:
                    ChangeMainContent(new ucFileCardQuestion(cardBoxes[0]));
                    ChangeSideBar(new ucSideBar());
                    break;
                case TargetPages.Settings:
                    ChangeMainContent(new ucSettings());
                    ChangeSideBar(new ucSettingsSideBar());
                    break;
                case TargetPages.NewProject:
                    ChangeMainContent(new ucNewProject());
                    break;
                default:
                    break;
            }
        }

        // switches back to Sign-In after signing out
        private void Topbar_SignOut(object sender, EventArgs e)
        {
            SignIn signIn = new SignIn();
            signIn.Show();
            this.Close();
        }

        private void SideBarComponent_ChangePageForEditing(object sender, ChangePageForEditing e)
        {
            switch (e.Target)
            {
                case TargetEditingPages.EditCardBox:
                    break;
                case TargetEditingPages.EditRegister:
                    break;
                case TargetEditingPages.EditFileCards:
                    ChangeMainContent(new ucSettingsNewFileCard(currentCardBox));
                    ChangeSideBar(new ucSettingsSideBar());
                    break;
                case TargetEditingPages.ImportFile:
                    break;
                case TargetEditingPages.ExportFile:
                    break;
                default:
                    break;
            }
        }

        private void BtnAnswer_PageChanged(object sender, ChangeQuestionToAnswer e)
        {
            ChangeMainContent(new ucFileCardAnswer());
        }

        private void BtnSettingsNext_PageChanged(object sender, SettingsNextFileCard e)
        {

            ChangeMainContent(new ucSettingsNewFileCard(currentCardBox));
        }

        private void TxtUserName_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

    }
}


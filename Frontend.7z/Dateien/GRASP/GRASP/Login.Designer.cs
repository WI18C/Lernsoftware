﻿namespace GRASP
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            this.LogoBox = new System.Windows.Forms.PictureBox();
            this.sideBarRight = new System.Windows.Forms.Panel();
            this.topBar = new System.Windows.Forms.Panel();
            this.mainPanel = new System.Windows.Forms.Panel();
            this.txtRegistryUserName = new System.Windows.Forms.TextBox();
            this.btnRegister = new System.Windows.Forms.Button();
            this.txtRegistryRepeatPassword = new System.Windows.Forms.TextBox();
            this.txtRegistryPassword = new System.Windows.Forms.TextBox();
            this.btnSignIn = new System.Windows.Forms.Button();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtUserName = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.LogoBox)).BeginInit();
            this.sideBarRight.SuspendLayout();
            this.mainPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // LogoBox
            // 
            this.LogoBox.Image = ((System.Drawing.Image)(resources.GetObject("LogoBox.Image")));
            this.LogoBox.Location = new System.Drawing.Point(68, 9);
            this.LogoBox.Name = "LogoBox";
            this.LogoBox.Size = new System.Drawing.Size(126, 123);
            this.LogoBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.LogoBox.TabIndex = 8;
            this.LogoBox.TabStop = false;
            // 
            // sideBarRight
            // 
            this.sideBarRight.Controls.Add(this.LogoBox);
            this.sideBarRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.sideBarRight.Location = new System.Drawing.Point(1640, 0);
            this.sideBarRight.Name = "sideBarRight";
            this.sideBarRight.Size = new System.Drawing.Size(262, 1033);
            this.sideBarRight.TabIndex = 8;
            // 
            // topBar
            // 
            this.topBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.topBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.topBar.Location = new System.Drawing.Point(0, 0);
            this.topBar.Name = "topBar";
            this.topBar.Size = new System.Drawing.Size(1640, 123);
            this.topBar.TabIndex = 9;
            // 
            // mainPanel
            // 
            this.mainPanel.Controls.Add(this.txtRegistryUserName);
            this.mainPanel.Controls.Add(this.btnRegister);
            this.mainPanel.Controls.Add(this.txtRegistryRepeatPassword);
            this.mainPanel.Controls.Add(this.txtRegistryPassword);
            this.mainPanel.Controls.Add(this.btnSignIn);
            this.mainPanel.Controls.Add(this.txtPassword);
            this.mainPanel.Controls.Add(this.txtUserName);
            this.mainPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainPanel.Location = new System.Drawing.Point(0, 123);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(1640, 910);
            this.mainPanel.TabIndex = 10;
            // 
            // txtRegistryUserName
            // 
            this.txtRegistryUserName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRegistryUserName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.txtRegistryUserName.Location = new System.Drawing.Point(435, 418);
            this.txtRegistryUserName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtRegistryUserName.Name = "txtRegistryUserName";
            this.txtRegistryUserName.Size = new System.Drawing.Size(322, 34);
            this.txtRegistryUserName.TabIndex = 20;
            this.txtRegistryUserName.Text = "User Name";
            // 
            // btnRegister
            // 
            this.btnRegister.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(214)))), ((int)(((byte)(165)))));
            this.btnRegister.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnRegister.ForeColor = System.Drawing.Color.White;
            this.btnRegister.Location = new System.Drawing.Point(435, 555);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(187, 45);
            this.btnRegister.TabIndex = 19;
            this.btnRegister.Text = "Register";
            this.btnRegister.UseVisualStyleBackColor = false;
            // 
            // txtRegistryRepeatPassword
            // 
            this.txtRegistryRepeatPassword.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRegistryRepeatPassword.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.txtRegistryRepeatPassword.Location = new System.Drawing.Point(435, 504);
            this.txtRegistryRepeatPassword.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtRegistryRepeatPassword.Name = "txtRegistryRepeatPassword";
            this.txtRegistryRepeatPassword.Size = new System.Drawing.Size(322, 34);
            this.txtRegistryRepeatPassword.TabIndex = 18;
            this.txtRegistryRepeatPassword.Text = "repeat Password";
            // 
            // txtRegistryPassword
            // 
            this.txtRegistryPassword.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRegistryPassword.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.txtRegistryPassword.Location = new System.Drawing.Point(435, 461);
            this.txtRegistryPassword.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtRegistryPassword.Name = "txtRegistryPassword";
            this.txtRegistryPassword.Size = new System.Drawing.Size(322, 34);
            this.txtRegistryPassword.TabIndex = 17;
            this.txtRegistryPassword.Text = "Password";
            // 
            // btnSignIn
            // 
            this.btnSignIn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(214)))), ((int)(((byte)(165)))));
            this.btnSignIn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSignIn.ForeColor = System.Drawing.Color.White;
            this.btnSignIn.Location = new System.Drawing.Point(435, 289);
            this.btnSignIn.Name = "btnSignIn";
            this.btnSignIn.Size = new System.Drawing.Size(187, 45);
            this.btnSignIn.TabIndex = 16;
            this.btnSignIn.Text = "Sign in";
            this.btnSignIn.UseVisualStyleBackColor = false;
            this.btnSignIn.Click += new System.EventHandler(this.BtnSignIn_Click);
            // 
            // txtPassword
            // 
            this.txtPassword.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassword.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.txtPassword.Location = new System.Drawing.Point(435, 239);
            this.txtPassword.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(322, 34);
            this.txtPassword.TabIndex = 15;
            this.txtPassword.Text = "Password";
            this.txtPassword.TextChanged += new System.EventHandler(this.TxtPassword_TextChanged);
            // 
            // txtUserName
            // 
            this.txtUserName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUserName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.txtUserName.Location = new System.Drawing.Point(435, 196);
            this.txtUserName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(322, 34);
            this.txtUserName.TabIndex = 14;
            this.txtUserName.Text = "User Name";
            this.txtUserName.TextChanged += new System.EventHandler(this.TxtUserName_TextChanged);
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 28F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1902, 1033);
            this.Controls.Add(this.mainPanel);
            this.Controls.Add(this.topBar);
            this.Controls.Add(this.sideBarRight);
            this.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Login";
            this.Text = "Login";
            ((System.ComponentModel.ISupportInitialize)(this.LogoBox)).EndInit();
            this.sideBarRight.ResumeLayout(false);
            this.mainPanel.ResumeLayout(false);
            this.mainPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox LogoBox;
        private System.Windows.Forms.Panel sideBarRight;
        private System.Windows.Forms.Panel topBar;
        private System.Windows.Forms.Panel mainPanel;
        private System.Windows.Forms.TextBox txtRegistryUserName;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.TextBox txtRegistryRepeatPassword;
        private System.Windows.Forms.TextBox txtRegistryPassword;
        private System.Windows.Forms.Button btnSignIn;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtUserName;
    }
}
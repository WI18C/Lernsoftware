﻿namespace GRASP
{
    partial class UserControlProjects
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonProject1 = new System.Windows.Forms.Button();
            this.buttonProject2 = new System.Windows.Forms.Button();
            this.buttonProject3 = new System.Windows.Forms.Button();
            this.buttonProject4 = new System.Windows.Forms.Button();
            this.buttonProject5 = new System.Windows.Forms.Button();
            this.buttonProject6 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnProject9 = new System.Windows.Forms.Button();
            this.btnProject8 = new System.Windows.Forms.Button();
            this.btnProject7 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonProject1
            // 
            this.buttonProject1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.buttonProject1.FlatAppearance.BorderSize = 0;
            this.buttonProject1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonProject1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonProject1.ForeColor = System.Drawing.Color.White;
            this.buttonProject1.Location = new System.Drawing.Point(93, 172);
            this.buttonProject1.Name = "buttonProject1";
            this.buttonProject1.Size = new System.Drawing.Size(255, 74);
            this.buttonProject1.TabIndex = 0;
            this.buttonProject1.Text = "Project 1";
            this.buttonProject1.UseVisualStyleBackColor = false;
            this.buttonProject1.Click += new System.EventHandler(this.ButtonProject1_Click);
            // 
            // buttonProject2
            // 
            this.buttonProject2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.buttonProject2.FlatAppearance.BorderSize = 0;
            this.buttonProject2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonProject2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonProject2.ForeColor = System.Drawing.Color.White;
            this.buttonProject2.Location = new System.Drawing.Point(93, 270);
            this.buttonProject2.Name = "buttonProject2";
            this.buttonProject2.Size = new System.Drawing.Size(255, 74);
            this.buttonProject2.TabIndex = 1;
            this.buttonProject2.Text = "Project 2";
            this.buttonProject2.UseVisualStyleBackColor = false;
            // 
            // buttonProject3
            // 
            this.buttonProject3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.buttonProject3.FlatAppearance.BorderSize = 0;
            this.buttonProject3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonProject3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonProject3.ForeColor = System.Drawing.Color.White;
            this.buttonProject3.Location = new System.Drawing.Point(93, 368);
            this.buttonProject3.Name = "buttonProject3";
            this.buttonProject3.Size = new System.Drawing.Size(255, 74);
            this.buttonProject3.TabIndex = 2;
            this.buttonProject3.Text = "Project 3";
            this.buttonProject3.UseVisualStyleBackColor = false;
            // 
            // buttonProject4
            // 
            this.buttonProject4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.buttonProject4.FlatAppearance.BorderSize = 0;
            this.buttonProject4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonProject4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonProject4.ForeColor = System.Drawing.Color.White;
            this.buttonProject4.Location = new System.Drawing.Point(373, 172);
            this.buttonProject4.Name = "buttonProject4";
            this.buttonProject4.Size = new System.Drawing.Size(255, 74);
            this.buttonProject4.TabIndex = 3;
            this.buttonProject4.Text = "Project 4";
            this.buttonProject4.UseVisualStyleBackColor = false;
            // 
            // buttonProject5
            // 
            this.buttonProject5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.buttonProject5.FlatAppearance.BorderSize = 0;
            this.buttonProject5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonProject5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonProject5.ForeColor = System.Drawing.Color.White;
            this.buttonProject5.Location = new System.Drawing.Point(373, 270);
            this.buttonProject5.Name = "buttonProject5";
            this.buttonProject5.Size = new System.Drawing.Size(255, 74);
            this.buttonProject5.TabIndex = 4;
            this.buttonProject5.Text = "Project 5";
            this.buttonProject5.UseVisualStyleBackColor = false;
            // 
            // buttonProject6
            // 
            this.buttonProject6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.buttonProject6.FlatAppearance.BorderSize = 0;
            this.buttonProject6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonProject6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonProject6.ForeColor = System.Drawing.Color.White;
            this.buttonProject6.Location = new System.Drawing.Point(373, 368);
            this.buttonProject6.Name = "buttonProject6";
            this.buttonProject6.Size = new System.Drawing.Size(255, 74);
            this.buttonProject6.TabIndex = 5;
            this.buttonProject6.Text = "Project 6";
            this.buttonProject6.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(214)))), ((int)(((byte)(165)))));
            this.label1.Location = new System.Drawing.Point(83, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(149, 59);
            this.label1.TabIndex = 7;
            this.label1.Text = "HOME";
            // 
            // btnProject9
            // 
            this.btnProject9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.btnProject9.FlatAppearance.BorderSize = 0;
            this.btnProject9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProject9.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProject9.ForeColor = System.Drawing.Color.White;
            this.btnProject9.Location = new System.Drawing.Point(651, 368);
            this.btnProject9.Name = "btnProject9";
            this.btnProject9.Size = new System.Drawing.Size(255, 74);
            this.btnProject9.TabIndex = 10;
            this.btnProject9.Text = "Project 9";
            this.btnProject9.UseVisualStyleBackColor = false;
            // 
            // btnProject8
            // 
            this.btnProject8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.btnProject8.FlatAppearance.BorderSize = 0;
            this.btnProject8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProject8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProject8.ForeColor = System.Drawing.Color.White;
            this.btnProject8.Location = new System.Drawing.Point(651, 270);
            this.btnProject8.Name = "btnProject8";
            this.btnProject8.Size = new System.Drawing.Size(255, 74);
            this.btnProject8.TabIndex = 9;
            this.btnProject8.Text = "Project 8";
            this.btnProject8.UseVisualStyleBackColor = false;
            // 
            // btnProject7
            // 
            this.btnProject7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.btnProject7.FlatAppearance.BorderSize = 0;
            this.btnProject7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProject7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProject7.ForeColor = System.Drawing.Color.White;
            this.btnProject7.Location = new System.Drawing.Point(651, 172);
            this.btnProject7.Name = "btnProject7";
            this.btnProject7.Size = new System.Drawing.Size(255, 74);
            this.btnProject7.TabIndex = 8;
            this.btnProject7.Text = "Project 7";
            this.btnProject7.UseVisualStyleBackColor = false;
            // 
            // UserControlProjects
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.Controls.Add(this.btnProject9);
            this.Controls.Add(this.btnProject8);
            this.Controls.Add(this.btnProject7);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonProject6);
            this.Controls.Add(this.buttonProject1);
            this.Controls.Add(this.buttonProject5);
            this.Controls.Add(this.buttonProject2);
            this.Controls.Add(this.buttonProject4);
            this.Controls.Add(this.buttonProject3);
            this.Name = "UserControlProjects";
            this.Size = new System.Drawing.Size(1640, 910);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonProject1;
        private System.Windows.Forms.Button buttonProject2;
        private System.Windows.Forms.Button buttonProject3;
        private System.Windows.Forms.Button buttonProject4;
        private System.Windows.Forms.Button buttonProject5;
        private System.Windows.Forms.Button buttonProject6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnProject9;
        private System.Windows.Forms.Button btnProject8;
        private System.Windows.Forms.Button btnProject7;
    }
}

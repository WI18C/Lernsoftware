﻿namespace GRASP
{
    partial class ucFileCardAnswer
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucFileCardAnswer));
            this.txtCount = new System.Windows.Forms.TextBox();
            this.btnAnswer = new System.Windows.Forms.Button();
            this.txtFileCard = new System.Windows.Forms.TextBox();
            this.btnMadeIt = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtCount
            // 
            this.txtCount.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCount.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.txtCount.Location = new System.Drawing.Point(447, 654);
            this.txtCount.Name = "txtCount";
            this.txtCount.Size = new System.Drawing.Size(112, 23);
            this.txtCount.TabIndex = 21;
            this.txtCount.Text = "1 / 25";
            // 
            // btnAnswer
            // 
            this.btnAnswer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(214)))), ((int)(((byte)(165)))));
            this.btnAnswer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnAnswer.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAnswer.ForeColor = System.Drawing.Color.White;
            this.btnAnswer.Location = new System.Drawing.Point(744, 632);
            this.btnAnswer.Name = "btnAnswer";
            this.btnAnswer.Size = new System.Drawing.Size(187, 45);
            this.btnAnswer.TabIndex = 20;
            this.btnAnswer.Text = "QUESTION";
            this.btnAnswer.UseVisualStyleBackColor = false;
            // 
            // txtFileCard
            // 
            this.txtFileCard.AcceptsReturn = true;
            this.txtFileCard.AcceptsTab = true;
            this.txtFileCard.BackColor = System.Drawing.SystemColors.Window;
            this.txtFileCard.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFileCard.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.txtFileCard.Location = new System.Drawing.Point(407, 205);
            this.txtFileCard.Multiline = true;
            this.txtFileCard.Name = "txtFileCard";
            this.txtFileCard.Size = new System.Drawing.Size(827, 500);
            this.txtFileCard.TabIndex = 19;
            this.txtFileCard.Text = "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod t" +
    "empor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua?";
            this.txtFileCard.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtFileCard.TextChanged += new System.EventHandler(this.TxtFileCard_TextChanged);
            // 
            // btnMadeIt
            // 
            this.btnMadeIt.BackColor = System.Drawing.Color.White;
            this.btnMadeIt.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnMadeIt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMadeIt.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMadeIt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(214)))), ((int)(((byte)(165)))));
            this.btnMadeIt.Image = ((System.Drawing.Image)(resources.GetObject("btnMadeIt.Image")));
            this.btnMadeIt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMadeIt.Location = new System.Drawing.Point(937, 632);
            this.btnMadeIt.Name = "btnMadeIt";
            this.btnMadeIt.Size = new System.Drawing.Size(187, 45);
            this.btnMadeIt.TabIndex = 22;
            this.btnMadeIt.Text = "MADE IT";
            this.btnMadeIt.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button1.Location = new System.Drawing.Point(551, 632);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(187, 45);
            this.button1.TabIndex = 23;
            this.button1.Text = "OOPS";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // ucFileCardAnswer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnMadeIt);
            this.Controls.Add(this.txtCount);
            this.Controls.Add(this.btnAnswer);
            this.Controls.Add(this.txtFileCard);
            this.Name = "ucFileCardAnswer";
            this.Size = new System.Drawing.Size(1640, 910);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtCount;
        private System.Windows.Forms.Button btnAnswer;
        private System.Windows.Forms.TextBox txtFileCard;
        private System.Windows.Forms.Button btnMadeIt;
        private System.Windows.Forms.Button button1;
    }
}

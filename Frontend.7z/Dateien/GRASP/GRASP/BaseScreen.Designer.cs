﻿namespace GRASP
{
    partial class BaseScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BaseScreen));
            this.sideBarRight = new System.Windows.Forms.Panel();
            this.LogoBox = new System.Windows.Forms.PictureBox();
            this.topBar = new System.Windows.Forms.Panel();
            this.buttonSignOut = new System.Windows.Forms.Button();
            this.buttonNewProject = new System.Windows.Forms.Button();
            this.buttonSettings = new System.Windows.Forms.Button();
            this.buttonTraining = new System.Windows.Forms.Button();
            this.buttonHome = new System.Windows.Forms.Button();
            this.mainPanel = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.project_base1 = new GRASP.Project_base();
            this.userControlProjects1 = new GRASP.UserControlProjects();
            this.sideBarRight.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LogoBox)).BeginInit();
            this.topBar.SuspendLayout();
            this.mainPanel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // sideBarRight
            // 
            this.sideBarRight.Controls.Add(this.LogoBox);
            this.sideBarRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.sideBarRight.Location = new System.Drawing.Point(1640, 0);
            this.sideBarRight.Name = "sideBarRight";
            this.sideBarRight.Size = new System.Drawing.Size(262, 1033);
            this.sideBarRight.TabIndex = 9;
            // 
            // LogoBox
            // 
            this.LogoBox.Image = ((System.Drawing.Image)(resources.GetObject("LogoBox.Image")));
            this.LogoBox.Location = new System.Drawing.Point(68, 9);
            this.LogoBox.Name = "LogoBox";
            this.LogoBox.Size = new System.Drawing.Size(126, 123);
            this.LogoBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.LogoBox.TabIndex = 8;
            this.LogoBox.TabStop = false;
            // 
            // topBar
            // 
            this.topBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.topBar.Controls.Add(this.buttonSignOut);
            this.topBar.Controls.Add(this.buttonNewProject);
            this.topBar.Controls.Add(this.buttonSettings);
            this.topBar.Controls.Add(this.buttonTraining);
            this.topBar.Controls.Add(this.buttonHome);
            this.topBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.topBar.Location = new System.Drawing.Point(0, 0);
            this.topBar.Name = "topBar";
            this.topBar.Size = new System.Drawing.Size(1640, 123);
            this.topBar.TabIndex = 11;
            // 
            // buttonSignOut
            // 
            this.buttonSignOut.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.buttonSignOut.FlatAppearance.BorderSize = 0;
            this.buttonSignOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSignOut.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSignOut.ForeColor = System.Drawing.Color.White;
            this.buttonSignOut.Image = ((System.Drawing.Image)(resources.GetObject("buttonSignOut.Image")));
            this.buttonSignOut.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSignOut.Location = new System.Drawing.Point(963, 29);
            this.buttonSignOut.Name = "buttonSignOut";
            this.buttonSignOut.Size = new System.Drawing.Size(190, 67);
            this.buttonSignOut.TabIndex = 4;
            this.buttonSignOut.Text = "   SIGN OUT";
            this.buttonSignOut.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSignOut.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonSignOut.UseVisualStyleBackColor = true;
            this.buttonSignOut.Click += new System.EventHandler(this.ButtonSignOut_Click);
            // 
            // buttonNewProject
            // 
            this.buttonNewProject.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.buttonNewProject.FlatAppearance.BorderSize = 0;
            this.buttonNewProject.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonNewProject.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonNewProject.ForeColor = System.Drawing.Color.White;
            this.buttonNewProject.Image = ((System.Drawing.Image)(resources.GetObject("buttonNewProject.Image")));
            this.buttonNewProject.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonNewProject.Location = new System.Drawing.Point(713, 29);
            this.buttonNewProject.Name = "buttonNewProject";
            this.buttonNewProject.Size = new System.Drawing.Size(223, 67);
            this.buttonNewProject.TabIndex = 3;
            this.buttonNewProject.Text = "    NEW PROJECT";
            this.buttonNewProject.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonNewProject.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonNewProject.UseVisualStyleBackColor = true;
            // 
            // buttonSettings
            // 
            this.buttonSettings.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.buttonSettings.FlatAppearance.BorderSize = 0;
            this.buttonSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSettings.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSettings.ForeColor = System.Drawing.Color.White;
            this.buttonSettings.Image = ((System.Drawing.Image)(resources.GetObject("buttonSettings.Image")));
            this.buttonSettings.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSettings.Location = new System.Drawing.Point(500, 29);
            this.buttonSettings.Name = "buttonSettings";
            this.buttonSettings.Size = new System.Drawing.Size(186, 67);
            this.buttonSettings.TabIndex = 2;
            this.buttonSettings.Text = "    SETTINGS";
            this.buttonSettings.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSettings.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonSettings.UseVisualStyleBackColor = true;
            // 
            // buttonTraining
            // 
            this.buttonTraining.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.buttonTraining.FlatAppearance.BorderSize = 0;
            this.buttonTraining.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTraining.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTraining.ForeColor = System.Drawing.Color.White;
            this.buttonTraining.Image = ((System.Drawing.Image)(resources.GetObject("buttonTraining.Image")));
            this.buttonTraining.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonTraining.Location = new System.Drawing.Point(278, 29);
            this.buttonTraining.Name = "buttonTraining";
            this.buttonTraining.Size = new System.Drawing.Size(195, 67);
            this.buttonTraining.TabIndex = 1;
            this.buttonTraining.Text = "    TRAINING";
            this.buttonTraining.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonTraining.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonTraining.UseVisualStyleBackColor = true;
            // 
            // buttonHome
            // 
            this.buttonHome.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.buttonHome.FlatAppearance.BorderSize = 0;
            this.buttonHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonHome.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonHome.ForeColor = System.Drawing.Color.White;
            this.buttonHome.Image = ((System.Drawing.Image)(resources.GetObject("buttonHome.Image")));
            this.buttonHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonHome.Location = new System.Drawing.Point(72, 29);
            this.buttonHome.Name = "buttonHome";
            this.buttonHome.Size = new System.Drawing.Size(179, 67);
            this.buttonHome.TabIndex = 0;
            this.buttonHome.Text = "    HOME";
            this.buttonHome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonHome.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonHome.UseVisualStyleBackColor = true;
            this.buttonHome.Click += new System.EventHandler(this.ButtonHome_Click);
            // 
            // mainPanel
            // 
            this.mainPanel.Controls.Add(this.panel1);
            this.mainPanel.Controls.Add(this.topBar);
            this.mainPanel.Controls.Add(this.sideBarRight);
            this.mainPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainPanel.Location = new System.Drawing.Point(0, 0);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(1902, 1033);
            this.mainPanel.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.project_base1);
            this.panel1.Controls.Add(this.userControlProjects1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 123);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1640, 910);
            this.panel1.TabIndex = 12;
            // 
            // project_base1
            // 
            this.project_base1.BackColor = System.Drawing.SystemColors.Window;
            this.project_base1.Location = new System.Drawing.Point(0, 0);
            this.project_base1.Name = "project_base1";
            this.project_base1.Size = new System.Drawing.Size(1640, 910);
            this.project_base1.TabIndex = 1;
            // 
            // userControlProjects1
            // 
            this.userControlProjects1.BackColor = System.Drawing.SystemColors.Window;
            this.userControlProjects1.Location = new System.Drawing.Point(0, 0);
            this.userControlProjects1.Name = "userControlProjects1";
            this.userControlProjects1.Size = new System.Drawing.Size(1640, 910);
            this.userControlProjects1.TabIndex = 0;
            // 
            // BaseScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1902, 1033);
            this.Controls.Add(this.mainPanel);
            this.ForeColor = System.Drawing.Color.White;
            this.Name = "BaseScreen";
            this.Text = "baseScreen";
            this.sideBarRight.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.LogoBox)).EndInit();
            this.topBar.ResumeLayout(false);
            this.mainPanel.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel sideBarRight;
        private System.Windows.Forms.PictureBox LogoBox;
        private System.Windows.Forms.Panel topBar;
        private System.Windows.Forms.Button buttonSignOut;
        private System.Windows.Forms.Button buttonNewProject;
        private System.Windows.Forms.Button buttonSettings;
        private System.Windows.Forms.Button buttonTraining;
        private System.Windows.Forms.Button buttonHome;
        private System.Windows.Forms.Panel mainPanel;
        private System.Windows.Forms.Panel panel1;
        private UserControlProjects userControlProjects1;
        private Project_base project_base1;
    }
}


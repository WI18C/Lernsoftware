﻿namespace GRASP
{
    partial class Project_base
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lblGeneral = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblCardBox = new System.Windows.Forms.Label();
            this.lblRegisters = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.lblFileCards = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.lblRegister2 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.lblRegister1 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.lblTrainings = new System.Windows.Forms.Label();
            this.lblSuccess = new System.Windows.Forms.Label();
            this.lblFileCards2 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.lblLastPracticed = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.lblRegister4 = new System.Windows.Forms.Label();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.lblRegister3 = new System.Windows.Forms.Label();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.lblRegister6 = new System.Windows.Forms.Label();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.lblRegister5 = new System.Windows.Forms.Label();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(214)))), ((int)(((byte)(165)))));
            this.label1.Location = new System.Drawing.Point(83, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(233, 60);
            this.label1.TabIndex = 17;
            this.label1.Text = "PROJECT 1";
            this.label1.Click += new System.EventHandler(this.Label1_Click);
            // 
            // lblGeneral
            // 
            this.lblGeneral.AutoSize = true;
            this.lblGeneral.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGeneral.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(214)))), ((int)(((byte)(165)))));
            this.lblGeneral.Location = new System.Drawing.Point(88, 148);
            this.lblGeneral.Name = "lblGeneral";
            this.lblGeneral.Size = new System.Drawing.Size(95, 28);
            this.lblGeneral.TabIndex = 21;
            this.lblGeneral.Text = "GENERAL";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(242, 204);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(392, 22);
            this.textBox1.TabIndex = 22;
            // 
            // lblCardBox
            // 
            this.lblCardBox.AutoSize = true;
            this.lblCardBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCardBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblCardBox.Location = new System.Drawing.Point(88, 197);
            this.lblCardBox.Name = "lblCardBox";
            this.lblCardBox.Size = new System.Drawing.Size(94, 28);
            this.lblCardBox.TabIndex = 23;
            this.lblCardBox.Text = "Card Box:";
            // 
            // lblRegisters
            // 
            this.lblRegisters.AutoSize = true;
            this.lblRegisters.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegisters.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblRegisters.Location = new System.Drawing.Point(88, 240);
            this.lblRegisters.Name = "lblRegisters";
            this.lblRegisters.Size = new System.Drawing.Size(94, 28);
            this.lblRegisters.TabIndex = 25;
            this.lblRegisters.Text = "Registers:";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(242, 247);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(392, 22);
            this.textBox2.TabIndex = 24;
            // 
            // lblFileCards
            // 
            this.lblFileCards.AutoSize = true;
            this.lblFileCards.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFileCards.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblFileCards.Location = new System.Drawing.Point(88, 283);
            this.lblFileCards.Name = "lblFileCards";
            this.lblFileCards.Size = new System.Drawing.Size(100, 28);
            this.lblFileCards.TabIndex = 27;
            this.lblFileCards.Text = "File Cards:";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(242, 290);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(392, 22);
            this.textBox3.TabIndex = 26;
            // 
            // lblRegister2
            // 
            this.lblRegister2.AutoSize = true;
            this.lblRegister2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegister2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblRegister2.Location = new System.Drawing.Point(88, 501);
            this.lblRegister2.Name = "lblRegister2";
            this.lblRegister2.Size = new System.Drawing.Size(102, 28);
            this.lblRegister2.TabIndex = 34;
            this.lblRegister2.Text = "Register 2:";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(316, 508);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(87, 22);
            this.textBox4.TabIndex = 33;
            // 
            // lblRegister1
            // 
            this.lblRegister1.AutoSize = true;
            this.lblRegister1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegister1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblRegister1.Location = new System.Drawing.Point(88, 458);
            this.lblRegister1.Name = "lblRegister1";
            this.lblRegister1.Size = new System.Drawing.Size(102, 28);
            this.lblRegister1.TabIndex = 32;
            this.lblRegister1.Text = "Register 1:";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(316, 465);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(87, 22);
            this.textBox5.TabIndex = 31;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblTotal.Location = new System.Drawing.Point(88, 415);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(58, 28);
            this.lblTotal.TabIndex = 30;
            this.lblTotal.Text = "Total:";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(316, 422);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(87, 22);
            this.textBox6.TabIndex = 29;
            // 
            // lblTrainings
            // 
            this.lblTrainings.AutoSize = true;
            this.lblTrainings.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTrainings.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(214)))), ((int)(((byte)(165)))));
            this.lblTrainings.Location = new System.Drawing.Point(88, 366);
            this.lblTrainings.Name = "lblTrainings";
            this.lblTrainings.Size = new System.Drawing.Size(112, 28);
            this.lblTrainings.TabIndex = 28;
            this.lblTrainings.Text = "TRAININGS";
            // 
            // lblSuccess
            // 
            this.lblSuccess.AutoSize = true;
            this.lblSuccess.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSuccess.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(214)))), ((int)(((byte)(165)))));
            this.lblSuccess.Location = new System.Drawing.Point(311, 366);
            this.lblSuccess.Name = "lblSuccess";
            this.lblSuccess.Size = new System.Drawing.Size(92, 28);
            this.lblSuccess.TabIndex = 35;
            this.lblSuccess.Text = "SUCCESS";
            // 
            // lblFileCards2
            // 
            this.lblFileCards2.AutoSize = true;
            this.lblFileCards2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFileCards2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(214)))), ((int)(((byte)(165)))));
            this.lblFileCards2.Location = new System.Drawing.Point(450, 366);
            this.lblFileCards2.Name = "lblFileCards2";
            this.lblFileCards2.Size = new System.Drawing.Size(113, 28);
            this.lblFileCards2.TabIndex = 39;
            this.lblFileCards2.Text = "FILE CARDS";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(455, 508);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(87, 22);
            this.textBox7.TabIndex = 38;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(455, 465);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(87, 22);
            this.textBox8.TabIndex = 37;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(455, 422);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(87, 22);
            this.textBox9.TabIndex = 36;
            // 
            // lblLastPracticed
            // 
            this.lblLastPracticed.AutoSize = true;
            this.lblLastPracticed.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLastPracticed.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(214)))), ((int)(((byte)(165)))));
            this.lblLastPracticed.Location = new System.Drawing.Point(605, 366);
            this.lblLastPracticed.Name = "lblLastPracticed";
            this.lblLastPracticed.Size = new System.Drawing.Size(160, 28);
            this.lblLastPracticed.TabIndex = 43;
            this.lblLastPracticed.Text = "LAST PRACTICED";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(610, 508);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(172, 22);
            this.textBox10.TabIndex = 42;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(610, 465);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(172, 22);
            this.textBox11.TabIndex = 41;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(610, 422);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(172, 22);
            this.textBox12.TabIndex = 40;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(198, 508);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(87, 22);
            this.textBox13.TabIndex = 46;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(198, 465);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(87, 22);
            this.textBox14.TabIndex = 45;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(198, 422);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(87, 22);
            this.textBox15.TabIndex = 44;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(198, 595);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(87, 22);
            this.textBox16.TabIndex = 56;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(198, 552);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(87, 22);
            this.textBox17.TabIndex = 55;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(610, 595);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(172, 22);
            this.textBox18.TabIndex = 54;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(610, 552);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(172, 22);
            this.textBox19.TabIndex = 53;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(455, 595);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(87, 22);
            this.textBox20.TabIndex = 52;
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(455, 552);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(87, 22);
            this.textBox21.TabIndex = 51;
            // 
            // lblRegister4
            // 
            this.lblRegister4.AutoSize = true;
            this.lblRegister4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegister4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblRegister4.Location = new System.Drawing.Point(88, 588);
            this.lblRegister4.Name = "lblRegister4";
            this.lblRegister4.Size = new System.Drawing.Size(102, 28);
            this.lblRegister4.TabIndex = 50;
            this.lblRegister4.Text = "Register 4:";
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(316, 595);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(87, 22);
            this.textBox22.TabIndex = 49;
            // 
            // lblRegister3
            // 
            this.lblRegister3.AutoSize = true;
            this.lblRegister3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegister3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblRegister3.Location = new System.Drawing.Point(88, 545);
            this.lblRegister3.Name = "lblRegister3";
            this.lblRegister3.Size = new System.Drawing.Size(102, 28);
            this.lblRegister3.TabIndex = 48;
            this.lblRegister3.Text = "Register 3:";
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(316, 552);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(87, 22);
            this.textBox23.TabIndex = 47;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(198, 683);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(87, 22);
            this.textBox24.TabIndex = 66;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(198, 640);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(87, 22);
            this.textBox25.TabIndex = 65;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(610, 683);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(172, 22);
            this.textBox26.TabIndex = 64;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(610, 640);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(172, 22);
            this.textBox27.TabIndex = 63;
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(455, 683);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(87, 22);
            this.textBox28.TabIndex = 62;
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(455, 640);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(87, 22);
            this.textBox29.TabIndex = 61;
            // 
            // lblRegister6
            // 
            this.lblRegister6.AutoSize = true;
            this.lblRegister6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegister6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblRegister6.Location = new System.Drawing.Point(88, 676);
            this.lblRegister6.Name = "lblRegister6";
            this.lblRegister6.Size = new System.Drawing.Size(102, 28);
            this.lblRegister6.TabIndex = 60;
            this.lblRegister6.Text = "Register 6:";
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(316, 683);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(87, 22);
            this.textBox30.TabIndex = 59;
            // 
            // lblRegister5
            // 
            this.lblRegister5.AutoSize = true;
            this.lblRegister5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegister5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblRegister5.Location = new System.Drawing.Point(88, 633);
            this.lblRegister5.Name = "lblRegister5";
            this.lblRegister5.Size = new System.Drawing.Size(102, 28);
            this.lblRegister5.TabIndex = 58;
            this.lblRegister5.Text = "Register 5:";
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(316, 640);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(87, 22);
            this.textBox31.TabIndex = 57;
            // 
            // Project_base
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.Controls.Add(this.textBox24);
            this.Controls.Add(this.textBox25);
            this.Controls.Add(this.textBox26);
            this.Controls.Add(this.textBox27);
            this.Controls.Add(this.textBox28);
            this.Controls.Add(this.textBox29);
            this.Controls.Add(this.lblRegister6);
            this.Controls.Add(this.textBox30);
            this.Controls.Add(this.lblRegister5);
            this.Controls.Add(this.textBox31);
            this.Controls.Add(this.textBox16);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.textBox19);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.textBox21);
            this.Controls.Add(this.lblRegister4);
            this.Controls.Add(this.textBox22);
            this.Controls.Add(this.lblRegister3);
            this.Controls.Add(this.textBox23);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.lblLastPracticed);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.lblFileCards2);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.lblSuccess);
            this.Controls.Add(this.lblRegister2);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.lblRegister1);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.lblTrainings);
            this.Controls.Add(this.lblFileCards);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.lblRegisters);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.lblCardBox);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblGeneral);
            this.Controls.Add(this.label1);
            this.Name = "Project_base";
            this.Size = new System.Drawing.Size(1640, 910);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblGeneral;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblCardBox;
        private System.Windows.Forms.Label lblRegisters;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label lblFileCards;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label lblRegister2;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label lblRegister1;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label lblTrainings;
        private System.Windows.Forms.Label lblSuccess;
        private System.Windows.Forms.Label lblFileCards2;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label lblLastPracticed;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Label lblRegister4;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Label lblRegister3;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.Label lblRegister6;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.Label lblRegister5;
        private System.Windows.Forms.TextBox textBox31;
    }
}

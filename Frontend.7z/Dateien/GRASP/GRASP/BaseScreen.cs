﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GRASP
{
    public partial class BaseScreen : Form
    {
        public BaseScreen()
        {
            InitializeComponent();

        }

        private void UserControlProjects1_Load(object sender, EventArgs e)
        {

        }

        private void ButtonHome_Click(object sender, EventArgs e)
        {

        }

        private void ButtonSignOut_Click(object sender, EventArgs e)
        {
            MessageBox.Show("See you soon.");
            
        }
    }
}

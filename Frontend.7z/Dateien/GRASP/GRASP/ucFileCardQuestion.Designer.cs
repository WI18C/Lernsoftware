﻿namespace GRASP
{
    partial class ucFileCardQuestion
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtFileCard = new System.Windows.Forms.TextBox();
            this.btnAnswer = new System.Windows.Forms.Button();
            this.txtCount = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtFileCard
            // 
            this.txtFileCard.AcceptsReturn = true;
            this.txtFileCard.AcceptsTab = true;
            this.txtFileCard.BackColor = System.Drawing.SystemColors.Window;
            this.txtFileCard.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFileCard.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.txtFileCard.Location = new System.Drawing.Point(403, 198);
            this.txtFileCard.Multiline = true;
            this.txtFileCard.Name = "txtFileCard";
            this.txtFileCard.Size = new System.Drawing.Size(827, 500);
            this.txtFileCard.TabIndex = 0;
            this.txtFileCard.Text = "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod t" +
    "empor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua?";
            this.txtFileCard.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtFileCard.TextChanged += new System.EventHandler(this.TxtFileCard_TextChanged);
            // 
            // btnAnswer
            // 
            this.btnAnswer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(214)))), ((int)(((byte)(165)))));
            this.btnAnswer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnAnswer.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAnswer.ForeColor = System.Drawing.Color.White;
            this.btnAnswer.Location = new System.Drawing.Point(740, 625);
            this.btnAnswer.Name = "btnAnswer";
            this.btnAnswer.Size = new System.Drawing.Size(187, 45);
            this.btnAnswer.TabIndex = 17;
            this.btnAnswer.Text = "ANSWER";
            this.btnAnswer.UseVisualStyleBackColor = false;
            // 
            // txtCount
            // 
            this.txtCount.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCount.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(48)))), ((int)(((byte)(160)))));
            this.txtCount.Location = new System.Drawing.Point(443, 647);
            this.txtCount.Name = "txtCount";
            this.txtCount.Size = new System.Drawing.Size(112, 23);
            this.txtCount.TabIndex = 18;
            this.txtCount.Text = "1 / 25";
            // 
            // ucFileCardQuestion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.Controls.Add(this.txtCount);
            this.Controls.Add(this.btnAnswer);
            this.Controls.Add(this.txtFileCard);
            this.Name = "ucFileCardQuestion";
            this.Size = new System.Drawing.Size(1640, 910);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtFileCard;
        private System.Windows.Forms.Button btnAnswer;
        private System.Windows.Forms.TextBox txtCount;
    }
}
